package service;

import entity.SiteAnnouncement;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 公告信息表 服务类
 * </p>
 *
 * @author 
 * @since 2024-11-25
 */
public interface SiteAnnouncementService extends IService<SiteAnnouncement> {

}
