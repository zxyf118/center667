package service;

import entity.SiteNews;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 新闻信息表 服务类
 * </p>
 *
 * @author 
 * @since 2024-12-02
 */
public interface SiteNewsService extends IService<SiteNews> {

}
