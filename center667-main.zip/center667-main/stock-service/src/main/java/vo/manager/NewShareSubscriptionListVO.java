package vo.manager;

import java.math.BigDecimal;
import java.util.Date;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

@Data
public class NewShareSubscriptionListVO {
	
	@ApiModelProperty(value = "申购记录id")
    private Integer id;

    @ApiModelProperty(value = "订单号")
    private String orderSn;

    @ApiModelProperty(value = "用户id")
    private Integer userId;
	
    @ApiModelProperty(value = "代理id")
    private Integer agentId;
    
    @ApiModelProperty(value = "代理名称")
    private String agentName;

    @ApiModelProperty(value = "新股id")
    private Integer newShareId;
    
    @ApiModelProperty(value = "新股代码")
    private String stockCode;

    @ApiModelProperty(value = "新股名称")
    private String stockName;
    
    @ApiModelProperty(value = "类型")
    private String stockType;

    @ApiModelProperty(value = "板块名称，如：科创、创业")
    private String stockPlate;
    
    @ApiModelProperty(value = "申购金额")
    private BigDecimal subscriptionAmount;
    
    @ApiModelProperty(value = "保证金")
    private BigDecimal bond;

    @ApiModelProperty(value = "申购价格")
    private BigDecimal buyingPrice;

    @ApiModelProperty(value = "申购数量")
    private Integer purchaseQuantity;

    @ApiModelProperty(value = "中签数量")
    private Integer awardQuantity;

    @ApiModelProperty(value = "申购状态：0、申购中，1、已中签，2、已认缴，3、转持仓，4、未中签，5、已过期，6、已取消")
    private Integer subscriptionStatus;

    @ApiModelProperty(value = "申购时间")
    private Date subscriptionTime;

    @ApiModelProperty(value = "杠杆倍数")
    private Integer lever;

    @ApiModelProperty(value = "中签时间")
    private Date awardTime;

    @ApiModelProperty(value = "认缴时间")
    private Date paymentTime;

    @ApiModelProperty(value = "转入持仓时间")
    private Date transferTime;

    @ApiModelProperty(value = "备注")
    private String remark;
    
    @ApiModelProperty(value = "用户可用金额")
    private BigDecimal availableAmt;
    
    @ApiModelProperty(value = "融资金额")
    private BigDecimal financingAmount;
    
    @ApiModelProperty(value = "融资年化利率")
    private BigDecimal annualizedInterestRate;
    
    @ApiModelProperty(value = "人民币兑换该股票币种汇率")
	private BigDecimal exchangeRate = BigDecimal.ONE;
}
