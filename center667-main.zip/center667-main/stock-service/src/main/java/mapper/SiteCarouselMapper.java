package mapper;

import entity.SiteCarousel;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-11-25
 */
public interface SiteCarouselMapper extends BaseMapper<SiteCarousel> {

}
