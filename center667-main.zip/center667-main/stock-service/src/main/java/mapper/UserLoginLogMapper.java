package mapper;

import entity.UserLoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-10-22
 */
public interface UserLoginLogMapper extends BaseMapper<UserLoginLog> {

}
