package mapper;

import entity.Country;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-10-22
 */
public interface CountryMapper extends BaseMapper<Country> {

}
