package vo.common;

import lombok.Data;

@Data
public class ChildAndParentVO {
	
	private Integer childId;
	
	private Integer parentId;
}
