package vo.server;

import lombok.Data;

@Data
public class UserLoginFailedTimesVO {
	private int times;
}
