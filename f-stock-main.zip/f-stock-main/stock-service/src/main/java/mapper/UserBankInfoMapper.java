package mapper;

import entity.UserBankInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author 
 * @since 2024-11-05
 */
public interface UserBankInfoMapper extends BaseMapper<UserBankInfo> {

}
