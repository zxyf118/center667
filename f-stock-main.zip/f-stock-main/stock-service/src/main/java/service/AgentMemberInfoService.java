package service;

import entity.AgentMemberInfo;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 代理的下级会员信息表 服务类
 * </p>
 *
 * @author 
 * @since 2024-11-01
 */
public interface AgentMemberInfoService extends IService<AgentMemberInfo> {

}
