package com.lottery.manager;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LotteryManagerApplicationTests {

	/**
	 * 测试写入首页统计报表
	 */
	@Test
	void contextLoads() {
		System.err.println(1);
	}

}
